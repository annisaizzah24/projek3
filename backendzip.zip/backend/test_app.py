import os
import io
import unittest
import datetime
from decimal import Decimal

# Set in-memory database URL before importing create_app
os.environ["DATABASE_URL"] = "sqlite:///:memory:"
os.environ["FLASK_ENV"] = "development"

from app import create_app, db
from app.models import User, Keluarga, Warga, ProgramBantuan, Verifikasi, PengajuanDesil, DESIL_INFO, get_desil_info
from app.verifikasi.engine import jalankan_verifikasi, AlreadyVerifiedError, NotFoundError


class SociovaultTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config["TESTING"] = True
        self.app.config["WTF_CSRF_ENABLED"] = False
        self.client = self.app.test_client()

        with self.app.app_context():
            db.session.remove()
            db.drop_all()
            db.create_all()

            # 1. Seed admin & petugas
            admin = User(username="admin", nama="Admin Test", role="admin")
            admin.set_password("admin123")
            db.session.add(admin)

            petugas = User(username="petugas1", nama="Petugas Test", role="petugas_verifikasi")
            petugas.set_password("petugas123")
            db.session.add(petugas)

            # 2. Seed 1 keluarga
            keluarga = Keluarga(
                nomor_kk="3201012345670001",
                kepala_keluarga="Bambang Test",
                alamat="Jl. Uji Coba No. 1"
            )
            db.session.add(keluarga)
            db.session.commit()

            # 3. Seed 1 program bantuan aktif dengan batas aset
            program = ProgramBantuan(
                nama_program="PKH Test",
                kriteria_penghasilan_max=Decimal("2000000.00"),
                kriteria_tanggungan_min=2,
                kriteria_aset_max=Decimal("15000000.00"),
                deskripsi="Program uji coba",
                is_active=True
            )
            db.session.add(program)
            db.session.commit()

            # 4. Seed 1 warga layak (penghasilan <= 2jt, tanggungan >= 2, aset <= 15jt)
            warga_layak = Warga(
                nik="3201010101900001",
                nama="Budi Layak",
                alamat="Jl. Sukajadi No. 10",
                id_keluarga=keluarga.id,
                penghasilan=Decimal("1200000.00"),
                jumlah_tanggungan=3,
                nilai_aset=Decimal("5000000.00"),
                tanggal_lahir=datetime.date(1990, 1, 1)
            )
            db.session.add(warga_layak)

            # 5. Seed 1 warga tidak layak (penghasilan 5jt > 2jt)
            warga_tidak_layak = Warga(
                nik="3201010202850002",
                nama="Siti Mampu",
                alamat="Jl. Sukajadi No. 12",
                id_keluarga=keluarga.id,
                penghasilan=Decimal("5000000.00"),
                jumlah_tanggungan=1,
                nilai_aset=Decimal("30000000.00"),
                tanggal_lahir=datetime.date(1985, 2, 2)
            )
            db.session.add(warga_tidak_layak)
            db.session.commit()

            # Simpan ID primitif untuk mencegah DetachedInstanceError
            self.admin_id = admin.id
            self.petugas_id = petugas.id
            self.keluarga_id = keluarga.id
            self.program_id = program.id
            self.warga_layak_id = warga_layak.id
            self.warga_tidak_layak_id = warga_tidak_layak.id

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    # =========================================================================
    # 4 SKENARIO UTAMA UNIT TEST FUNGSI jalankan_verifikasi
    # =========================================================================

    def test_jalankan_verifikasi_layak(self):
        """Skenario 1: Evaluasi warga yang memenuhi kriteria menghasilkan status 'layak'."""
        with self.app.app_context():
            verif = jalankan_verifikasi(self.warga_layak_id, self.program_id, id_petugas=self.petugas_id)

            self.assertIsNotNone(verif.id)
            self.assertEqual(verif.status_otomatis, "layak")
            self.assertEqual(verif.status_sistem, "layak")
            self.assertIsNone(verif.status_final)
            self.assertIsNone(verif.tanggal_konfirmasi)

            # Audit breakdown
            detail = verif.detail_pengecekan
            self.assertTrue(detail["kriteria_pengecekan"]["penghasilan"]["lolos"])
            self.assertTrue(detail["kriteria_pengecekan"]["tanggungan"]["lolos"])
            self.assertTrue(detail["kriteria_pengecekan"]["aset"]["lolos"])

    def test_jalankan_verifikasi_tidak_layak(self):
        """Skenario 2: Evaluasi warga yang melebihi batas menghasilkan status 'tidak_layak'."""
        with self.app.app_context():
            verif = jalankan_verifikasi(self.warga_tidak_layak_id, self.program_id, id_petugas=self.petugas_id)

            self.assertIsNotNone(verif.id)
            self.assertEqual(verif.status_otomatis, "tidak_layak")
            self.assertIsNone(verif.status_final)

            detail = verif.detail_pengecekan
            self.assertFalse(detail["kriteria_pengecekan"]["penghasilan"]["lolos"])
            self.assertFalse(detail["kriteria_pengecekan"]["tanggungan"]["lolos"])
            self.assertFalse(detail["kriteria_pengecekan"]["aset"]["lolos"])

    def test_jalankan_verifikasi_perlu_ditinjau_data_kosong(self):
        """Skenario 3: Jika ada field warga relevan yang kosong -> status 'perlu_ditinjau' & catat field kurang."""
        with self.app.app_context():
            # Masukkan data warga dengan alamat kosong secara langsung ke database
            db.session.execute(
                db.text(
                    "INSERT INTO warga (id, id_keluarga, nik, nama, alamat, penghasilan, jumlah_tanggungan, nilai_aset, tanggal_lahir) "
                    "VALUES (999, :id_k, '3201019900112233', 'Warga Kurang', '', 1000000.0, 2, 0.0, '1995-05-05')"
                ),
                {"id_k": self.keluarga_id}
            )
            db.session.commit()

            verif = jalankan_verifikasi(999, self.program_id, id_petugas=self.petugas_id)

            self.assertEqual(verif.status_otomatis, "perlu_ditinjau")
            self.assertIn("alamat", verif.detail_pengecekan["field_kurang"])

    def test_jalankan_verifikasi_tolak_sudah_terdaftar(self):
        """Skenario 4: Tolak proses jika warga sudah pernah terdaftar (layak/perlu_ditinjau) pada program yang sama."""
        with self.app.app_context():
            # Verifikasi pertama kali berhasil
            jalankan_verifikasi(self.warga_layak_id, self.program_id, id_petugas=self.petugas_id)

            # Verifikasi kedua kali pada warga & program yang sama harus ditolak dengan error
            with self.assertRaises(AlreadyVerifiedError):
                jalankan_verifikasi(self.warga_layak_id, self.program_id, id_petugas=self.petugas_id)

    # =========================================================================
    # UNIT TEST TAMBAHAN (ENDPOINT, RBAC, FORM & KONFIRMASI)
    # =========================================================================

    def test_konfirmasi_hanya_bisa_sekali(self):
        """Uji coba aturan: Petugas mengisi status_final, HANYA BISA SEKALI (tolak jika tanggal_konfirmasi sudah terisi)."""
        # Login sebagai petugas
        self.client.post("/auth/login", data={"username": "petugas1", "password": "petugas123"})

        with self.app.app_context():
            verif = jalankan_verifikasi(self.warga_layak_id, self.program_id, id_petugas=self.petugas_id)
            verif_id = verif.id

        # Konfirmasi pertama kali: Berhasil
        res1 = self.client.post(f"/verifikasi/{verif_id}/konfirmasi", data={
            "status_final": "layak",
            "catatan_petugas": "Telah disurvei dan disetujui."
        }, follow_redirects=True)
        self.assertEqual(res1.status_code, 200)

        with self.app.app_context():
            v_check = db.session.get(Verifikasi, verif_id)
            self.assertEqual(v_check.status_final, "layak")
            self.assertIsNotNone(v_check.tanggal_konfirmasi)

        # Konfirmasi kedua kali: Ditolak (pesan flash error)
        res2 = self.client.post(f"/verifikasi/{verif_id}/konfirmasi", data={
            "status_final": "tidak_layak",
            "catatan_petugas": "Coba ubah status lagi"
        }, follow_redirects=True)
        self.assertIn(b"sudah pernah dikonfirmasi", res2.data)

    def test_role_access_control_petugas_forbidden_program_tambah(self):
        """Petugas verifikasi tidak memiliki hak untuk menambah program bantuan (403 Forbidden)."""
        self.client.post("/auth/login", data={"username": "petugas1", "password": "petugas123"})
        res = self.client.get("/program/tambah")
        self.assertEqual(res.status_code, 403)
        self.assertIn(b"403", res.data)
        self.assertIn(b"Akses Ditolak", res.data)

    def test_warga_inline_validation_error(self):
        """Form warga harus menampilkan pesan error inline jika NIK tidak tepat 16 digit."""
        self.client.post("/auth/login", data={"username": "petugas1", "password": "petugas123"})
        res = self.client.post("/warga/tambah", data={
            "nik": "12345",  # Invalid: hanya 5 digit
            "id_keluarga": self.keluarga_id,
            "nama": "Tester Invalid",
            "alamat": "Jl. Uji Coba",
            "tanggal_lahir": "1995-01-01",
            "penghasilan": "1000000",
            "jumlah_tanggungan": "1",
            "nilai_aset": "0"
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"is-invalid", res.data)
        self.assertIn(b"NIK harus tepat 16 digit", res.data)

    def test_program_crud_admin(self):
        """Admin dapat membuat dan memperbarui master program bantuan sosial."""
        self.client.post("/auth/login", data={"username": "admin", "password": "admin123"})

        # 1. Tambah program baru
        res_tambah = self.client.post("/program/tambah", data={
            "nama_program": "Bansos Sembako",
            "kriteria_penghasilan_max": "1500000.00",
            "kriteria_tanggungan_min": "1",
            "kriteria_aset_max": "10000000.00",
            "deskripsi": "Bantuan sembako bulanan"
        }, follow_redirects=True)
        self.assertEqual(res_tambah.status_code, 200)
        self.assertIn(b"Bansos Sembako", res_tambah.data)

        # 2. Edit program yang baru dibuat
        with self.app.app_context():
            prog = ProgramBantuan.query.filter_by(nama_program="Bansos Sembako").first()
            prog_id = prog.id

        res_edit = self.client.post(f"/program/{prog_id}/edit", data={
            "nama_program": "Bansos Sembako Diperbarui",
            "kriteria_penghasilan_max": "1800000.00",
            "kriteria_tanggungan_min": "2",
            "kriteria_aset_max": "12000000.00",
            "deskripsi": "Deskripsi baru"
        }, follow_redirects=True)
        self.assertEqual(res_edit.status_code, 200)
        self.assertIn(b"Bansos Sembako Diperbarui", res_edit.data)

    def test_verifikasi_flow_via_form(self):
        """Menjalankan evaluasi verifikasi melalui form POST /verifikasi/mulai."""
        self.client.post("/auth/login", data={"username": "petugas1", "password": "petugas123"})
        res = self.client.post("/verifikasi/mulai", data={
            "id_warga": self.warga_layak_id,
            "id_program": self.program_id,
            "catatan": "Verifikasi formulir test"
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"LAYAK", res.data)
        self.assertIn(b"Detail Audit Verifikasi", res.data)

    def test_custom_404_page(self):
        """Halaman 404 khusus harus tampil ketika mengakses route yang tidak ada."""
        res = self.client.get("/halaman-yang-pasti-tidak-ada")
        self.assertEqual(res.status_code, 404)
        self.assertIn(b"404", res.data)
        self.assertIn(b"Halaman Tidak Ditemukan", res.data)

    def test_registrasi_warga_sukses(self):
        """Warga dapat mendaftar akun baru dan otomatis memiliki role warga."""
        res = self.client.post("/auth/register", data={
            "nama": "Warga Baru Mandiri",
            "nik": "3201010101900001",
            "username": "wargabaru",
            "password": "password123",
            "konfirmasi_password": "password123"
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Pendaftaran berhasil", res.data)

        with self.app.app_context():
            u = User.query.filter_by(username="wargabaru").first()
            self.assertIsNotNone(u)
            self.assertEqual(u.role, "warga")
            self.assertEqual(u.nik, "3201010101900001")
            self.assertTrue(u.is_warga)
            self.assertFalse(u.is_admin)

    def test_registrasi_warga_mismatch_password(self):
        """Validasi inline menolak pendaftaran jika konfirmasi password tidak cocok."""
        res = self.client.post("/auth/register", data={
            "nama": "Warga Mismatch",
            "nik": "3201010101900002",
            "username": "wargabeda",
            "password": "password123",
            "konfirmasi_password": "passwordBERBEDA"
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"is-invalid", res.data)
        self.assertIn(b"Konfirmasi password tidak cocok", res.data)

    def test_dashboard_warga_view(self):
        """Pengguna dengan role warga melihat dashboard portal warga dengan status bansos miliknya."""
        # 1. Daftarkan warga
        self.client.post("/auth/register", data={
            "nama": "Budi Layak",
            "nik": "3201010101900001",
            "username": "budilayak",
            "password": "password123",
            "konfirmasi_password": "password123"
        }, follow_redirects=True)

        # 2. Login sebagai warga
        self.client.post("/auth/login", data={"username": "budilayak", "password": "password123"})

        # 3. Buka dashboard
        res = self.client.get("/dashboard")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Portal Warga", res.data)
        self.assertIn(b"Status Verifikasi Bantuan Sosial Saya", res.data)
        self.assertIn(b"Data Kependudukan", res.data)

    # =========================================================================
    # SKENARIO PENGUJIAN DESIL & PENGAJUAN PERUBAHAN DESIL
    # =========================================================================

    def test_desil_metadata_dan_auto_calculation(self):
        """Validasi metadata Desil 1-10 dan algoritma penghitungan otomatis berbasis penghasilan & aset."""
        self.assertEqual(len(DESIL_INFO), 10)
        
        # Desil 1-4 layak bansos
        self.assertTrue(get_desil_info(1)["is_layak_bansos"])
        self.assertTrue(get_desil_info(2)["is_layak_bansos"])
        self.assertTrue(get_desil_info(3)["is_layak_bansos"])
        self.assertTrue(get_desil_info(4)["is_layak_bansos"])
        
        # Desil 5-10 tidak layak bansos
        self.assertFalse(get_desil_info(5)["is_layak_bansos"])
        self.assertFalse(get_desil_info(7)["is_layak_bansos"])
        self.assertFalse(get_desil_info(10)["is_layak_bansos"])

        # Properti keterangan_desil pada model Warga
        with self.app.app_context():
            w = db.session.get(Warga, self.warga_layak_id)
            w.desil = 1
            info = w.keterangan_desil
            self.assertIn("Sangat Miskin", info["kategori"])
            self.assertTrue(info["is_layak_bansos"])
            self.assertIn("rumah_desil1", w.foto_rumah_url)

            # Auto-kalkulasi desil pada instance warga jika desil belum diset
            w.desil = None
            w.penghasilan = Decimal("800000.00")
            w.jumlah_tanggungan = 2
            self.assertEqual(w.hitung_desil_otomatis(), 1)

            w.penghasilan = Decimal("1500000.00")
            w.jumlah_tanggungan = 0
            self.assertEqual(w.hitung_desil_otomatis(), 2)

            w.penghasilan = Decimal("2500000.00")
            w.jumlah_tanggungan = 0
            self.assertEqual(w.hitung_desil_otomatis(), 3)

            w.penghasilan = Decimal("3500000.00")
            w.jumlah_tanggungan = 0
            self.assertEqual(w.hitung_desil_otomatis(), 4)

            w.penghasilan = Decimal("4500000.00")
            w.jumlah_tanggungan = 0
            self.assertEqual(w.hitung_desil_otomatis(), 5)

            w.penghasilan = Decimal("8000000.00")
            w.jumlah_tanggungan = 0
            self.assertEqual(w.hitung_desil_otomatis(), 7)

            w.penghasilan = Decimal("18000000.00")
            w.jumlah_tanggungan = 0
            self.assertEqual(w.hitung_desil_otomatis(), 9)

            w.penghasilan = Decimal("30000000.00")
            w.jumlah_tanggungan = 0
            self.assertEqual(w.hitung_desil_otomatis(), 10)

    def test_engine_verifikasi_kriteria_desil_max(self):
        """Rule engine menolak warga jika desilnya melebihi kriteria_desil_max program."""
        with self.app.app_context():
            # Set program hanya untuk Desil <= 3
            prog = db.session.get(ProgramBantuan, self.program_id)
            prog.kriteria_desil_max = 3
            db.session.commit()

            # Buat warga dengan desil 7 (terdata mampu) meskipun gaji & aset kecil
            warga_salah_desil = Warga(
                nik="3201019999990001",
                nama="Warga Salah Desil",
                alamat="Jl. Sempit No. 5",
                id_keluarga=self.keluarga_id,
                penghasilan=Decimal("900000.00"),
                jumlah_tanggungan=3,
                nilai_aset=Decimal("4000000.00"),
                desil=7,
                tanggal_lahir=datetime.date(1990, 1, 1)
            )
            db.session.add(warga_salah_desil)
            db.session.commit()
            w_id = warga_salah_desil.id

            # Verifikasi dijalankan dalam app_context: harus TIDAK LAYAK karena desil 7 > 3
            hasil = jalankan_verifikasi(w_id, self.program_id)
            self.assertEqual(hasil.status_otomatis, "tidak_layak")
            self.assertFalse(hasil.detail_pengecekan["kriteria_pengecekan"]["desil"]["lolos"])
            self.assertIn("melebihi batas maksimal program (Maksimal Desil 3)", hasil.detail_pengecekan["ringkasan"])
            self.assertIn("Desil 7", hasil.detail_pengecekan["ringkasan"])

    def test_pengajuan_perubahan_desil_oleh_warga(self):
        """Warga yang desilnya salah dapat mengajukan permohonan perubahan desil dengan bukti foto rumah."""
        # 1. Buat data warga dengan Desil 7
        with self.app.app_context():
            warga = Warga(
                nik="3201018888880001",
                nama="Ratna Sanggah",
                alamat="Kampung Cibaduyut",
                id_keluarga=self.keluarga_id,
                penghasilan=Decimal("850000.00"),
                jumlah_tanggungan=2,
                nilai_aset=Decimal("3000000.00"),
                desil=7,
                tanggal_lahir=datetime.date(1992, 3, 3)
            )
            db.session.add(warga)
            db.session.commit()
            w_id = warga.id

        # 2. Registrasi akun user warga
        self.client.post("/auth/register", data={
            "nama": "Ratna Sanggah",
            "nik": "3201018888880001",
            "username": "ratna_sanggah",
            "password": "password123",
            "konfirmasi_password": "password123"
        }, follow_redirects=True)

        # 3. Login warga
        self.client.post("/auth/login", data={"username": "ratna_sanggah", "password": "password123"})

        # 4. GET form ajukan perubahan desil
        res_get = self.client.get("/pengajuan-desil/ajukan")
        self.assertEqual(res_get.status_code, 200)
        self.assertIn(b"Pengajuan Perubahan Desil", res_get.data)
        self.assertIn(b"Desil 7", res_get.data)

        # 5. POST pengajuan perubahan desil ke Desil 1 beserta bukti foto rumah
        dummy_photo = (io.BytesIO(b"dummy image data"), "rumah_bilik.jpg")
        res_post = self.client.post("/pengajuan-desil/ajukan", data={
            "desil_diajukan": 1,
            "penghasilan_terkini": "850000.00",
            "jumlah_tanggungan": 2,
            "foto_rumah": dummy_photo,
            "alasan_pengajuan": "Data kelurahan tercatat Desil 7 padahal kondisi riil tergolong miskin penghasilan buruh cuci."
        }, content_type="multipart/form-data", follow_redirects=True)
        self.assertEqual(res_post.status_code, 200)
        self.assertIn(b"Permohonan perubahan desil berhasil diajukan", res_post.data)

        # 6. Periksa data tersimpan di database
        with self.app.app_context():
            pengajuan = PengajuanDesil.query.filter_by(id_warga=w_id).first()
            self.assertIsNotNone(pengajuan)
            self.assertEqual(pengajuan.desil_lama, 7)
            self.assertEqual(pengajuan.desil_diajukan, 1)
            self.assertEqual(pengajuan.status, "menunggu")
            self.assertIn("uploads/rumah/", pengajuan.foto_rumah_baru)

        # 7. Cek riwayat warga
        res_riwayat = self.client.get("/pengajuan-desil/saya")
        self.assertEqual(res_riwayat.status_code, 200)
        self.assertIn(b"Menunggu Verifikasi", res_riwayat.data)
        self.assertIn(b"Desil 1", res_riwayat.data)

    def test_petugas_setujui_perubahan_desil_dan_verifikasi_bansos_lolos(self):
        """Persetujuan petugas otomatis memperbarui desil & penghasilan warga dan meloloskan bansos."""
        with self.app.app_context():
            # Setup program PKH (maks desil 3)
            prog = db.session.get(ProgramBantuan, self.program_id)
            prog.kriteria_desil_max = 3

            # Buat warga terdata Desil 7
            warga = Warga(
                nik="3201017777770001",
                nama="Bambang Kurang Mampu",
                alamat="Jl. Cikutra No. 9",
                id_keluarga=self.keluarga_id,
                penghasilan=Decimal("800000.00"),
                jumlah_tanggungan=3,
                nilai_aset=Decimal("3000000.00"),
                desil=7,
                tanggal_lahir=datetime.date(1989, 4, 4)
            )
            db.session.add(warga)
            db.session.flush()

            # Buat pengajuan perubahan ke Desil 1
            pengajuan = PengajuanDesil(
                id_warga=warga.id,
                id_user=self.admin_id,
                desil_lama=7,
                desil_diajukan=1,
                penghasilan_terkini=Decimal("800000.00"),
                jumlah_tanggungan=3,
                foto_rumah_baru="uploads/rumah/test_rumah.jpg",
                alasan_pengajuan="Data desil 7 keliru, kondisi keluarga tergolong miskin ekstrem.",
                status="menunggu",
                tanggal_pengajuan=datetime.datetime.now()
            )
            db.session.add(pengajuan)
            db.session.commit()
            p_id = pengajuan.id
            w_id = warga.id

        # Petugas login
        self.client.post("/auth/login", data={"username": "petugas1", "password": "petugas123"})

        # Petugas melihat antrean pengajuan
        res_list = self.client.get("/pengajuan-desil")
        self.assertEqual(res_list.status_code, 200)
        self.assertIn(b"Bambang Kurang Mampu", res_list.data)

        # Petugas menyetujui pengajuan
        res_approve = self.client.post(f"/pengajuan-desil/{p_id}", data={
            "status": "disetujui",
            "desil_disetujui": 1,
            "catatan_petugas": "Telah disurvei langsung, kondisi fisik rumah dan slip gaji terbukti sesuai Desil 1."
        }, follow_redirects=True)
        self.assertEqual(res_approve.status_code, 200)
        self.assertIn(b"disetujui", res_approve.data)

        # Verifikasi data profil warga ter-update
        with self.app.app_context():
            w = db.session.get(Warga, w_id)
            self.assertEqual(w.desil, 1)
            self.assertEqual(w.penghasilan, Decimal("800000.00"))
            self.assertEqual(w.foto_rumah, "uploads/rumah/test_rumah.jpg")

            p = db.session.get(PengajuanDesil, p_id)
            self.assertEqual(p.status, "disetujui")

            # Uji verifikasi bansos: sekarang harus lolos LAYAK karena desil sudah 1 <= 3!
            hasil = jalankan_verifikasi(w_id, self.program_id)
            self.assertEqual(hasil.status_otomatis, "layak")
            self.assertTrue(hasil.detail_pengecekan["kriteria_pengecekan"]["desil"]["lolos"])

    def test_petugas_tolak_pengajuan_desil(self):
        """Penolakan perubahan desil oleh petugas tidak mengubah data desil profil warga."""
        with self.app.app_context():
            warga = Warga(
                nik="3201016666660001",
                nama="Warga Ditolak",
                alamat="Jl. Mewah No. 1",
                id_keluarga=self.keluarga_id,
                penghasilan=Decimal("6000000.00"),
                jumlah_tanggungan=1,
                nilai_aset=Decimal("80000000.00"),
                desil=8,
                tanggal_lahir=datetime.date(1987, 5, 5)
            )
            db.session.add(warga)
            db.session.flush()

            pengajuan = PengajuanDesil(
                id_warga=warga.id,
                id_user=self.admin_id,
                desil_lama=8,
                desil_diajukan=2,
                penghasilan_terkini=Decimal("1500000.00"),
                jumlah_tanggungan=1,
                foto_rumah_baru="uploads/rumah/test_rumah.jpg",
                alasan_pengajuan="Mengajukan perubahan desil ke desil 2.",
                status="menunggu",
                tanggal_pengajuan=datetime.datetime.now()
            )
            db.session.add(pengajuan)
            db.session.commit()
            p_id = pengajuan.id
            w_id = warga.id

        # Petugas login
        self.client.post("/auth/login", data={"username": "petugas1", "password": "petugas123"})

        # Petugas menolak pengajuan
        res_reject = self.client.post(f"/pengajuan-desil/{p_id}", data={
            "status": "ditolak",
            "desil_disetujui": 8,
            "catatan_petugas": "Kondisi rumah mewah dan aset bernilai tinggi, pengajuan ditolak."
        }, follow_redirects=True)
        self.assertEqual(res_reject.status_code, 200)

        with self.app.app_context():
            p = db.session.get(PengajuanDesil, p_id)
            self.assertEqual(p.status, "ditolak")
            w = db.session.get(Warga, w_id)
            # Desil tetap 8, tidak berubah!
            self.assertEqual(w.desil, 8)

    def test_hak_akses_antrean_pengajuan_desil(self):
        """Warga publik tidak memiliki hak akses membuka antrean review petugas."""
        # Daftarkan dan login warga
        self.client.post("/auth/register", data={
            "nama": "Warga Awam",
            "nik": "3201010101900001",
            "username": "wargaawam",
            "password": "password123",
            "konfirmasi_password": "password123"
        }, follow_redirects=True)
        self.client.post("/auth/login", data={"username": "wargaawam", "password": "password123"})

        # Coba buka antrean verifikasi petugas (role_required admin & petugas_verifikasi)
        res = self.client.get("/pengajuan-desil", follow_redirects=True)
        self.assertEqual(res.status_code, 403)
        self.assertIn(b"403", res.data)
        self.assertIn(b"Akses Ditolak", res.data)


if __name__ == "__main__":
    unittest.main()
