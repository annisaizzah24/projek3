import datetime
from decimal import Decimal
from flask import render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required
from sqlalchemy.exc import IntegrityError
from app.warga import warga_bp
from app.models import Warga, Keluarga, Verifikasi, DESIL_INFO, get_desil_info
from app.extensions import db
from app.forms import WargaForm, KeluargaForm
from app.auth.routes import role_required
from app.desil.routes import simpan_berkas_unggah


# =============================================================================
# 1. DAFTAR WARGA: GET /warga (Search NIK/Nama & Filter Keluarga & Filter Desil)
# =============================================================================
@warga_bp.route("/warga", methods=["GET"])
@login_required
def daftar_warga():
    search = request.args.get("search", "").strip()
    id_keluarga = request.args.get("keluarga", "").strip() or request.args.get("id_keluarga", "").strip()
    desil_filter = request.args.get("desil", "").strip()
    page = max(1, request.args.get("page", 1, type=int))
    per_page = max(1, min(100, request.args.get("per_page", 10, type=int)))

    query = Warga.query.join(Keluarga, Warga.id_keluarga == Keluarga.id)

    if search:
        wildcard = f"%{search}%"
        query = query.filter(
            db.or_(
                Warga.nik.ilike(wildcard),
                Warga.nama.ilike(wildcard)
            )
        )

    if id_keluarga:
        if id_keluarga.isdigit() and len(id_keluarga) != 16:
            query = query.filter(Warga.id_keluarga == int(id_keluarga))
        else:
            query = query.filter(Keluarga.nomor_kk == id_keluarga)

    if desil_filter and desil_filter.isdigit():
        query = query.filter(Warga.desil == int(desil_filter))

    pagination = query.order_by(Warga.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    daftar_keluarga = Keluarga.query.order_by(Keluarga.nomor_kk.asc()).all()

    if request.headers.get("Accept") == "application/json" or request.args.get("format") == "json":
        items = [{
            "id": w.id,
            "nik": w.nik,
            "nama": w.nama,
            "alamat": w.alamat,
            "nomor_kk": w.keluarga.nomor_kk if w.keluarga else None,
            "id_keluarga": w.id_keluarga,
            "penghasilan": float(w.penghasilan),
            "jumlah_tanggungan": w.jumlah_tanggungan,
            "nilai_aset": float(w.nilai_aset or 0.0),
            "desil": w.desil,
            "keterangan_desil": w.keterangan_desil,
            "foto_rumah": w.foto_rumah,
            "tanggal_lahir": w.tanggal_lahir.isoformat() if w.tanggal_lahir else None
        } for w in pagination.items]
        return jsonify({
            "success": True,
            "total": pagination.total,
            "page": page,
            "per_page": per_page,
            "items": items
        })

    return render_template(
        "warga/index.html",
        pagination=pagination,
        daftar_keluarga=daftar_keluarga,
        search=search,
        selected_keluarga=id_keluarga,
        desil_filter=desil_filter,
        desil_info=DESIL_INFO
    )


# =============================================================================
# 2. TAMBAH WARGA: GET / POST /warga/tambah (Flask-WTF)
# =============================================================================
@warga_bp.route("/warga/tambah", methods=["GET", "POST"])
@login_required
@role_required("admin", "petugas_verifikasi")
def tambah_warga():
    form = WargaForm()

    if form.validate_on_submit():
        try:
            foto_path = None
            if form.foto_rumah.data:
                foto_path = simpan_berkas_unggah(form.foto_rumah.data, folder="rumah")

            desil_val = form.desil.data if (form.desil.data and form.desil.data > 0) else None

            warga_baru = Warga(
                nik=form.nik.data.strip(),
                nama=form.nama.data.strip(),
                alamat=form.alamat.data.strip(),
                id_keluarga=form.id_keluarga.data,
                penghasilan=form.penghasilan.data,
                jumlah_tanggungan=form.jumlah_tanggungan.data or 0,
                nilai_aset=form.nilai_aset.data or Decimal("0.00"),
                tanggal_lahir=form.tanggal_lahir.data,
                desil=desil_val,
                foto_rumah=foto_path
            )

            if not warga_baru.desil:
                warga_baru.desil = warga_baru.hitung_desil_otomatis()

            db.session.add(warga_baru)
            db.session.commit()
            flash(f"Warga '{warga_baru.nama}' (NIK: {warga_baru.nik}) berhasil didaftarkan dengan kategori Desil {warga_baru.desil}.", "success")
            return redirect(url_for("warga.daftar_warga"))
        except IntegrityError:
            db.session.rollback()
            form.nik.errors.append(f"NIK '{form.nik.data}' sudah terdaftar dalam sistem database.")
        except Exception as exc:
            db.session.rollback()
            flash(f"Gagal menyimpan data warga: {str(exc)}", "danger")

    return render_template("warga/form_warga.html", form=form, is_edit=False)


# =============================================================================
# 3. EDIT WARGA: GET / POST /warga/<id>/edit (Flask-WTF)
# =============================================================================
@warga_bp.route("/warga/<int:id>/edit", methods=["GET", "POST"])
@login_required
@role_required("admin", "petugas_verifikasi")
def edit_warga(id):
    warga = db.get_or_404(Warga, id)
    form = WargaForm(current_warga_id=warga.id, obj=warga)

    if request.method == "GET":
        form.desil.data = warga.desil or 0

    if form.validate_on_submit():
        try:
            warga.nik = form.nik.data.strip()
            warga.nama = form.nama.data.strip()
            warga.alamat = form.alamat.data.strip()
            warga.id_keluarga = form.id_keluarga.data
            warga.penghasilan = form.penghasilan.data
            warga.jumlah_tanggungan = form.jumlah_tanggungan.data or 0
            warga.nilai_aset = form.nilai_aset.data or Decimal("0.00")
            warga.tanggal_lahir = form.tanggal_lahir.data

            if form.desil.data and form.desil.data > 0:
                warga.desil = form.desil.data
            else:
                warga.desil = warga.hitung_desil_otomatis()

            if form.foto_rumah.data:
                foto_path = simpan_berkas_unggah(form.foto_rumah.data, folder="rumah")
                if foto_path:
                    warga.foto_rumah = foto_path

            db.session.commit()
            flash(f"Data warga '{warga.nama}' berhasil diperbarui.", "success")
            return redirect(url_for("warga.daftar_warga"))
        except IntegrityError:
            db.session.rollback()
            form.nik.errors.append("NIK sudah digunakan oleh warga lain.")
        except Exception as exc:
            db.session.rollback()
            flash(f"Gagal memperbarui data: {str(exc)}", "danger")

    return render_template("warga/form_warga.html", form=form, warga=warga, is_edit=True)


# =============================================================================
# 4. HAPUS WARGA: POST /warga/<id>/hapus (Protected via ON DELETE RESTRICT)
# =============================================================================
@warga_bp.route("/warga/<int:id>/hapus", methods=["POST"])
@login_required
@role_required("admin", "petugas_verifikasi")
def hapus_warga(id):
    warga = db.get_or_404(Warga, id)

    verif_count = Verifikasi.query.filter_by(id_warga=warga.id).count()
    if verif_count > 0:
        flash(
            f"Warga '{warga.nama}' tidak dapat dihapus karena memiliki {verif_count} data historis verifikasi bantuan sosial.",
            "danger"
        )
        return redirect(url_for("warga.daftar_warga"))

    try:
        nama = warga.nama
        db.session.delete(warga)
        db.session.commit()
        flash(f"Warga '{nama}' berhasil dihapus dari sistem.", "success")
    except IntegrityError:
        db.session.rollback()
        flash("Gagal menghapus warga: Terdapat relasi data lain yang masih terikat.", "danger")
    except Exception as exc:
        db.session.rollback()
        flash(f"Gagal menghapus warga: {str(exc)}", "danger")

    return redirect(url_for("warga.daftar_warga"))


# =============================================================================
# 5. TAMBAH KELUARGA: GET / POST /keluarga/tambah (Flask-WTF)
# =============================================================================
@warga_bp.route("/keluarga/tambah", methods=["GET", "POST"])
@login_required
@role_required("admin", "petugas_verifikasi")
def tambah_keluarga():
    form = KeluargaForm()

    if form.validate_on_submit():
        try:
            keluarga_baru = Keluarga(
                nomor_kk=form.nomor_kk.data.strip(),
                kepala_keluarga=form.kepala_keluarga.data.strip(),
                alamat=form.alamat.data.strip()
            )
            db.session.add(keluarga_baru)
            db.session.commit()
            flash(f"Kartu Keluarga No. {keluarga_baru.nomor_kk} ({keluarga_baru.kepala_keluarga}) berhasil didaftarkan.", "success")
            return redirect(url_for("warga.daftar_warga"))
        except IntegrityError:
            db.session.rollback()
            form.nomor_kk.errors.append("Nomor KK sudah terdaftar dalam database.")
        except Exception as exc:
            db.session.rollback()
            flash(f"Gagal mendaftarkan keluarga: {str(exc)}", "danger")

    return render_template("warga/form_keluarga.html", form=form)
